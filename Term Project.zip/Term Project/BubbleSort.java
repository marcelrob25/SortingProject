//Marcel Robinson
import java.util.Random;

import java.util.Scanner;



public class Bubblesort

{

     

      public static void main(String args[])

      {

          

            Scanner sc = new Scanner(System.in);

          ze

            System.out.print("Enter number: ");

            int inputSize = sc.nextInt();

        

            int[] array = new int[inputSize];


            Random rand = new Random();

            for(int i=0;i<inputSize;i++)

            {

                  array[i] = rand.nextInt(100);

            }

           

            System.out.println("Before Bubble sort");

            for(int i=0;i<inputSize;i++)

            {

                  System.out.print(array[i]+" ");

            }

            System.out.println("\nSort the numbers using bubble sort: ");

           

          

            int temp;

            

            for (int c = 0 ; c < ( inputSize - 1 ); c++)

            {

                  for (int j = 0 ; j < inputSize - c - 1; j++)

                  {

                        if (array[j] > array[j+1])

                        {

                              temp = array[j];

                              array[j] = array[j+1];

                              array[j+1] = temp;

                        }

                  }

            }
            for(int i=0;i<inputSize;i++)

            {
                  System.out.print(array[i]+" ");

            }

      }

}