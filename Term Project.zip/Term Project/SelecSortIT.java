//Marcel Robinson

import java.util.Random;

import java.util.Scanner;



public class SelectionSortIterations

{

 

      public static void main(String args[]){

      

            Scanner sc = new Scanner(System.in);

         

            System.out.print("Enter number: ");

            int inputSize = sc.nextInt();

            System.out.print("Enter number of iterations: ");

            int num_iter = sc.nextInt();

         

            int[] array = new int[inputSize];


            Random rand = new Random();

     

            for(int i=0;i<inputSize;i++)

            {

                  array[i] = rand.nextInt(100);

            }

      

            System.out.println("Before Selection sort");

       

            for(int i=0;i<inputSize;i++)

            {

                  System.out.print(array[i]+" ");

            }

   

            System.out.println("\nSort the numbers using Selection sort: ");

    

            int sortedcount = 0;

      

            long startTime = System.currentTimeMillis();

    

            for (int i = 0; i < num_iter-1; i++)

            {

                  

                  int min_index = i;

                  for (int temp = i+1; temp < inputSize; temp++)

                        if (array[temp] < array[min_index])

                        {

                              min_index = temp;

                        }

               

                  int temp = array[min_index];

                  array[min_index] = array[i];

                  array[i] = temp;

                  sortedcount++;

            }

           

            long endTime = System.currentTimeMillis();


            long totalTime = endTime - startTime;

           

            System.out.println("Total iterations: "+num_iter);

            System.out.println("Total numbers sorted : "+sortedcount);

            System.out.println("Total time taken: "+totalTime);

          

            for(int i=0;i<inputSize;i++)

            {

                  System.out.print(array[i]+" ");

            }

      }

}