//Marcel Robinson

import java.util.Random;

import java.util.Scanner;



public class Bubblesortiterations

{

    

      public static void main(String args[]){

        

            Scanner sc = new Scanner(System.in);


            System.out.print("Enter number: ");

            int inputSize = sc.nextInt();

            System.out.print("Enter number of iterations: ");

            int num_iter = sc.nextInt();

         

            int[] array = new int[inputSize];

        

            Random rand = new Random();

       

            for(int i=0;i<inputSize;i++)

            {

                  array[i] = rand.nextInt(100);

            }


            System.out.println("Before Bubble sort");

     

            for(int i=0;i<inputSize;i++)

            {

                  System.out.print(array[i]+" ");

            }

            System.out.println("\nSort the numbers using Bubble sort: ");

         

            int temp,sortedcount = 0;    

           

            long startTime = System.currentTimeMillis();


            for (int c = 0 ; c < ( num_iter - 1 ); c++)

            {

                  for (int d = 0 ; d < num_iter - c - 1; d++)

                  {

                        if (array[d] > array[d+1])

                        {

                              temp = array[d];

                              array[d] = array[d+1];

                              array[d+1] = temp;

                              sortedcount++;

                        }

                  }

            }


            long endTime = System.currentTimeMillis();

        
            long totalTime = endTime - startTime;


            System.out.println("Total iterations: "+num_iter);

            System.out.println("Total numbers sorted : "+sortedcount);

            System.out.println("Total time taken: "+totalTime);

            System.out.println("After Bubble sort");

            for(int i=0;i<inputSize;i++){

                  System.out.print(array[i]+" ");

            }

      }

}