//Marcel Robinson
import java.util.Random;

import java.util.Scanner;

public class Selectionsort

{

     

      public static void main(String args[]){

       

            Scanner sc = new Scanner(System.in);


            System.out.print("Enter number: ");

            int inputSize = sc.nextInt();

       

            int[] array = new int[inputSize];

        

            Random rand = new Random();

          

            for(int i=0;i<inputSize;i++)

            {

                  array[i] = rand.nextInt(100);

            }

      

            System.out.println("Before Selection sort");

            for(int i=0;i<inputSize;i++)

            {

                  System.out.print(array[i]+" ");

            }

  

            System.out.println("\nSort the numbers using Selection sort: ");

     

            for (int i = 0; i < inputSize-1; i++)

            {

           

                  int min_index = i;

                  for (int j = i+1; j < inputSize; j++)

                        if (array[j] < array[min_index])

                        {

                              min_index = j;

                        }

                  int temp = array[min_index];

                  array[min_index] = array[i];

                  array[i] = temp;

            }

    
            for(int i=0;i<inputSize;i++)

            {

                  System.out.print(array[i]+" ");

            }

      }    

}